import {Component} from '@angular/core';

/**
 * @title Multi-row toolbar
 */
@Component({
  selector: 'toolbar-multirow-example',
  templateUrl: 'toolbar-multirow-example.html',
  styleUrls: ['toolbar-multirow-example.css'],
})
export class ToolbarMultirowExample {}
