import {Component} from '@angular/core';


/**
 * @title Badge overview
 */
@Component({
  selector: 'badge-overview-example',
  templateUrl: 'badge-overview-example.html',
  styleUrls: ['badge-overview-example.css']
})
export class BadgeOverviewExample { }
