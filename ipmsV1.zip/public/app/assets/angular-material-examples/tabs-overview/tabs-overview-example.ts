import {Component} from '@angular/core';

/**
 * @title Basic tabs
 */
@Component({
  selector: 'tabs-overview-example',
  templateUrl: 'tabs-overview-example.html',
  styleUrls: ['tabs-overview-example.css'],
})
export class TabsOverviewExample {}
