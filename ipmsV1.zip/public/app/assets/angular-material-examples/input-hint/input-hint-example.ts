import {Component} from '@angular/core';

/**
 * @title Input with hints
 */
@Component({
  selector: 'input-hint-example',
  templateUrl: 'input-hint-example.html',
  styleUrls: ['input-hint-example.css'],
})
export class InputHintExample {}
