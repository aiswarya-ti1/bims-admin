import {Component} from '@angular/core';

/** @title Datepicker with custom icon */
@Component({
  selector: 'datepicker-custom-icon-example',
  templateUrl: 'datepicker-custom-icon-example.html',
  styleUrls: ['datepicker-custom-icon-example.css'],
})
export class DatepickerCustomIconExample {}
