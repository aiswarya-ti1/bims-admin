<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class login_users extends Model
{
    //
}
