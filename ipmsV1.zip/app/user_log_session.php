<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class user_log_session extends Model
{
    //
}
