<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class dashboardController extends Controller
{
    public function getSession()
	{
		$sessions=\DB::table('session')->get();/*->map(function ($item) {
    return get_object_vars($item);});*/
	$response=array('response'=>'session start','success'=>true,$sessions);
		return $response;
	}
}
