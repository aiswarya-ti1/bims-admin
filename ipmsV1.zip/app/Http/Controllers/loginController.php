<?php

namespace App\Http\Controllers;
//use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Session;
use Request;
use App\login;
use App\Roles;
use App\user_roles;
use App\user_log_session;
use Hash;
use Illuminate\Support\Facades\Crypt;

class LoginController extends Controller
{
	
    public function login(Request $req)
	{
		try
		{
		$user=new login;
		$role=new Roles;
		$user_role=new user_roles;
		$userlog=new user_log_session;
		$inputs = Request::json()->all();
		//$response =array('response'=>'success', $inputs);
		//return $response;
$user->User_Login = $inputs['username'];
$user->User_Password = $inputs['password'];
//$trim=str_replace("'","",$user->User_Login);
//$username=$req->input('username');
//$password=$req->input('password');
//echo $user->User_Login, $user->User_Password ;
$hash=Hash::make($user->User_Password);
//echo $password;
	$users=login::select('User_Password')->where('User_Login',$inputs['username'])->first();
	//echo $users;	s
	//$response=array($users,$hash);
	//return $response;
	
		if(Hash::check($user->User_Password, $users->User_Password)) {
			$user_details=\DB::table('logins')
			->join ('user_roles', 'logins.User_ID', '=','user_roles.user_ID')
			->join ('roles','logins.Role_ID','=','roles.Role_ID')
			->select('logins.User_Name','logins.User_ID','logins.User_Image','logins.User_Status','roles.Role_Name','logins.User_Email','roles.Role_ID')
			->where('logins.User_Login',$inputs['username'])
			->get()->map(function ($item) {
    return get_object_vars($item);});
	  //echo $user_details;
//echo $user_details[0]['User_Name'];
			//$user_details = $user_details->row();
			//$result=$data = get_object_vars($user_details);
			
			//echo $user_details[0]->User_Name;
			//echo json($user_details)->toArray();
   //echo $user_details[0]['User_ID'];;
  if(!empty($user_details))
   {
	   //echo 'userdetails not empty';
	  // echo $user_details;
	  /* $session=\DB::table('session')->insert(array(
            'UserName'     =>   $user_details[0]['User_Name'], 
            'UserID'   =>   $user_details[0]['User_ID'],            
			'UserImage'   =>   $user_details[0]['User_Image'],            
			'UserStatus'   =>   $user_details[0]['User_Status'],            
			'RoleName'   =>   $user_details[0]['Role_Name'],            
			'User_Email'   =>   $user_details[0]['User_Email'],          
			  'Role_ID'   =>   $user_details[0]['Role_ID']
     )
);*/
  $ip = $_SERVER["REMOTE_ADDR"];
  //echo $ip;
$log=\DB::table('user_log_sessions')->insert(array(
'user_ID' =>$user_details[0]['User_ID'],
'Log_IP' => $ip));


	/*session()->put('UserName',$user_details->User_Name);
				session()->put('UserImage',$user_details->User_Image);		
				session()->put('Role',$user_details->Role_Name);*/
  // }
		}
$response=array('response'=>'login success..','success'=>true,'Session added','Log Session added',$user_details,$user->User_Password,$users->User_Password, $hash);
		return $response;
			//echo "login success..";
		}
		else
		{
			$response=array('response'=>'login failed','success'=>false,$user->User_Password,$users->User_Password, $hash);
		return $response;
		}
	}
	
	
		
		catch(Exception $e)
		{
			$response=array('response'=>'failed..','success'=>false);
		return $response;
		return $e;

			echo "enter valid info..";
		}
	}
		

	public function getUserPermission($userID)
{
	$perm=\DB::table('logins')
				->join('user_roles','logins.User_ID','=','user_roles.User_ID')
				->join('userrole_privillage', 'userrole_privillage.Role_ID', '=', 'user_roles.role_ID')
				->join('menu_previllage', 'menu_previllage.Priv_ID','=','userrole_privillage.Priv_ID')
				->leftjoin('menu_details','menu_details.Priv_ID','=','menu_previllage.Priv_ID')
				->where('logins.User_ID',$userID)
                ->where('menu_previllage.Parent_ID', '!=', -1)
				->select('menu_previllage.IsActive','menu_previllage.priv_ID','menu_previllage.Parent_ID','menu_details.*')
				->get();
	 $res=array($perm);
	 return $res;
	
}


	public function logout($value)
	{
		$now = new \DateTime();
		try{
		$logID=\DB::table('user_log_sessions')->max('Log_ID');
		\DB::table('session')->where('UserId',$value)->delete();
		$response=array('response'=>'session cleared','success'=>true);
		$UpdateDetails = \DB::table('user_log_sessions')
            ->where('Log_ID',$logID)
            ->update(array('Log_Ottime'=>$now,'Log_Status'=>200, 'Log_St_Desc'=>'Login Success'));
			$response=array('response'=>'session cleared','success'=>true,'Log table updated');
			//echo 'updated';
			return $response;
		}
		catch(Exception $e) {
        return $e;
    }
	}
	public function getHash()
	{
		$logName=Request::json()->all();
		$hash=Hash::make('admin');
		$resp=array($hash);
		return $resp;
		
	}
}




