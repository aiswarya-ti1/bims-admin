<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Input;
//use Illuminate\Http\Request;
use Request;
use File;
use Illuminate\Support\Facades\Crypt;
use Hash;

class adminController extends Controller
{
 //To get brands list.
    public function getBrands()
	{
		$brands=\DB::table('prod_brands')->get();
		//$brandCount=count($brands);
		$brandResp=array($brands);
		return $brandResp;
	}
	//To get segments list
	public function getAdminSegments()
	{
		$seg=\DB::table('prod_segment')->select('Seg_ID','Seg_Name')->get();
		$segCount=count($seg);
		$segResp=array($seg,$segCount);
		return $segResp;
	}
	
	////to get Group list per segment
	public function getGroupSegments($id)
	{
		$groupList=\DB::table('prod_groups')->select('Group_ID','Group_Name')
		->where('Seg_ID', $id)->get();
		$groupResp=array($groupList);
		return $groupResp;
	}
	//to get Categorylist per group
	public function getCatGroups($id)
	{
		$catList=\DB::table('prod_categories')->select('Category_ID','Category_Name')->where('Group_ID',$id)->get();
		$CatResp=array($catList);
		return $CatResp;
	}
	//toget subcategories by Category
	public function getSubCatByCat($id)
	{
		$subList=\DB::table('prod_sub_category')->select('SubCat_ID','SubCat_Name')
		->where('Cat_ID',$id)->get();
		$subResp=array($subList);
		return $subResp;
	}
	//to get attribute list
	public function getAttributes()
	{
		$AttrList=\DB::table('prod_attributes')->select('Attrb_ID','Attrb_Name')
		->get();
		$AttrResp=array($AttrList);
		return $AttrResp;
	}
	public function getGroups()
	{
		$groups=\DB::table('prod_groups')->select('Group_ID','Group_Name')->get();
		$listresp=array($groups);
		return $listresp;
	}
	public function getCategories()
	{
		$cats=\DB::table('prod_categories')->select('Category_ID','Category_Name')->get();
		$catList=array($cats);
		return $catList;
	}
	//To add new Group
	public function addNewGroup(Request $g)
	{
			$group = Request::json()->all();
		$newgroup=\DB::table('prod_groups')->insert(array('Group_Name' => $group['group'], 'Seg_ID' =>$group['seg']));
		$groupCount=count($newgroup);
		$groupResp=array($newgroup, $groupCount);
		return $groupResp;
	}
	
	//to add new brand
	public function addNewBrand(Request $b)
	{
		
		$name = Request::json()->all();
		$newBrand=\DB::table('prod_brands')->insert(array('Brand_Name' => $name['brand']));
		$resp=array($newBrand);
		return $resp;
	}
	//to add new Segment
	public function eg(Request $s)
	{
		
		$seg = Request::json()->all();
		$newSeg=\DB::table('prod_segment')->insert(array('Seg_Name' => $seg['segment']));
		$resp=array($newSeg);
		return $resp;
	}
	public function addNewCat(Request $r)
	{
		$cat=Request::json()->all();
		$newCat=\DB::table('prod_categories')->insert(array('Category_Name' =>$cat['category'], 'Group_ID'=>$cat['group']));
		$resp=array($newCat);
		return $resp;
	}
	public function SubCat(Request $r)
	{
		$subCat=Request::json()->all();
		$newSubCat=\DB::table('prod_sub_category')->insert(array('SubCat_Name' =>$subCat['subCategory'], 'Cat_ID'=>$subCat['category']));
		$resp=array($newSubCat);
		return $resp;
	}
	public function addNewAttrb(Request $r)
	{
		$data=Request::json()->all();
		$newAttrb=\DB::table('prod_attributes')->insert(array('Attrb_Name' => $data['subCategory']));
		$res=array($newAttrb);
		return $res;
	}
	public function addCSVFile(Request $req)
	{
		
		$uploads=Request::file('fileKey');
		$filePath=$uploads->getRealPath();
		
		$file=fopen($filePath, 'r');
		$header = fgetcsv($file);
		$escapeHeader=array();
		foreach($header as $key =>$value)
		{
			$lheader= strtolower($header);
			$escapedItem=preg_replace('/[^a-z]/','', $header);
			array_push($escapeHeader, $header);
			
			while($columns = fgetcsv($file))
			{
				if($columns[0]=="")
				{
					continue;
				}
				foreach($columns as $key => &$value)
				{
				 $value=preg_replace('/\D/','', $value);	
				}
				$data = array_combine($escapeHeader, $columns);
				$insert=\DB::table('demo')->insert(array('id' => $data['id'], 'name'=>$data['name'], 'age'=>$data['age']));
					
				
			}
		}
		
		$resp=array($header);
		return $resp;
		
	}
	public function SerSeg(Request $r)
	{
		$seg=Request::json()->all();
		$newSeg=\DB::table('serv_segments')->insert(array('SerSeg_Name' => $seg['segment']));
		$resp=array($newSeg);
		return $resp;
	}
	public function getSerSegments()
	{
		$serSegments=\DB::table('serv_segments')->select('SerSeg_ID','SerSeg_Name') -> get();
		$serResp=array($serSegments);
		return $serResp;
		
	}
	public function SerCat(Request $r)
	{
		$ser=Request::json()->all();
		$newSer=\DB::table('services')->insert(array('Service_Name' => $ser['cat'], 'Segment_ID' => $ser['seg']));
		$resp=array($newSer);
		return $resp;
	}
	public function addNewProduct(Request $r)
	{
		/*$details=Request::json()->all();
		$descr=$details['descr'];
		$cat=\DB::table('prod_categories')->where('Category_ID', $details['cat'])->pluck('Category_Name');
	//$name=array_shift($cat);
//$name=(string)$cat;
		if(!empty($details['subCat']))
		{
			$subcat=\DB::table('prod_sub_category')->where('SubCat_ID', $details['subCat'])->pluck('SubCat_Name');
			//$subname=serialize($subcat);
			//$subCatName=$subcat['SubCat_Name'];
		}
		$productName=$cat[0]." ".$subcat[0]." ".$descr;
		
		$words = explode(" ", ucwords($productName));
$acronym = "";

foreach ($words as $w) {
  $acronym .= $w[0];
}
preg_match('/[^ ]*$/', $descr, $results);
$last_word = $results[0];
$code= 'P'.$acronym.$last_word;

$newProduct=\DB::table('products')->insertGetID(array('Prod_Code' => $code,
 'Prod_Name'=> $productName, 
'Group_ID' => $details['group'],
'Seg_ID' => $details['seg'],
'Brand_ID' => $details['brand'],
'Model' => $details['cat'],
'Item' => $details['subCat'],
'Descr' => $details['descr']
));
if(!empty($newProduct))
{
	$attrb=\DB::table('prod_attribute_value') ->insert(array(
	array('Prod_ID' =>$newProduct,'Attrb_ID' => $details['spec1'],'Attrb_Value' => $details['value1']),
	array('Prod_ID' =>$newProduct,'Attrb_ID' => $details['spec2'],'Attrb_Value' => $details['value2']),
	array('Prod_ID' =>$newProduct,'Attrb_ID' => $details['spec3'],'Attrb_Value' => $details['value3']),
	array('Prod_ID' =>$newProduct,'Attrb_ID' => $details['spec4'],'Attrb_Value' => $details['value4']),
	array('Prod_ID' =>$newProduct,'Attrb_ID' => $details['spec5'],'Attrb_Value' => $details['value5']))
	);
	$resp=array('Product Inserted', $newProduct);
		return $resp;
	
	
}*/

//$prodName=$details['itemName']." ".$details['Attr1']." ".$details['Attr2']." "/*.$details['Attr3']." ".$details['Attr4']." ".$details['Attr5']." ".$details['Attr6']." ".$details['Attr7']." ".$details['Attr8']." "*/.$details['Attr9'];

/*$itemName=$r->input('itemName');
$Attr1=$r->input('Attr1');
$Attr2=$r->input('Attr2');
$Attr3=$r->input('Attr3');
$Attr4=$r->input('Attr4');
$Attr5=$r->input('Attr5');
$Attr6=$r->input('Attr6');
$Attr7=$r->input('Attr7');
$Attr8=$r->input('Attr8');
$Attr9=$r->input('Attr9');
$seg=$r->input('seg');
$group=$r->input('group');
$brand=$r->input('brand');*/
$details=Request::json()->all();
$itemName=$details['itemName'];
$Attr1=$details['Attr1'];
$Attr2=$details['Attr2'];
$Attr3=$details['Attr3'];
$Attr4=$details['Attr4'];
$Attr5=$details['Attr5'];
$Attr6=$details['Attr6'];
$Attr7=$details['Attr7'];
$Attr8=$details['Attr8'];
$Attr9=$details['Attr9'];
$seg=$details['seg'];
$group=$details['group'];
$brand=$details['brand'];
$prodName=$itemName." ".$Attr1." ".$Attr2." ".$Attr3." ".$Attr4." ".$Attr5." ".$Attr6." ".$Attr7." ".$Attr8." ".$Attr9;

$newProd=\DB::table('products')
->insertGetID(array('ItemName' => $itemName, 'Prod_Name'=>$prodName, 'Group_ID'=>$group, 'UnitofMeasure' =>$Attr9));


if(!empty($newProd))
{
	if(!empty($Attr1))
{
		$chkAttr1=\DB::table('attrb_value_rel')->where('Attrb_Value', $Attr1)->pluck('Attrb_Value_ID');
		

		if(!$chkAttr1->isEmpty())		
		{

		$insertAttr1=\DB::table('prod_attribute_value')->insert(array('Prod_ID' => $newProd, 'Attrb_ID' => '1', 'Attrb_Value_ID' =>$chkAttr1[0]));
			
				
		}
		
	
		else
		{
		$attr1ID=\DB::table('attrb_value_rel')->insertGetID(array('Attrb_ID' => '1' , 'Attrb_Value' => $Attr1));
		$insertAttr1=\DB::table('prod_attribute_value')->insert(array('Prod_ID' => $newProd, 'Attrb_ID' => '1', 'Attrb_Value_ID' =>$attr1ID));
			
		}
		
	}



	if(!empty($Attr2))
	{
		$chkAttr2=\DB::table('attrb_value_rel')->where('Attrb_Value', $Attr2)->pluck('Attrb_Value_ID');

		if(!$chkAttr2->isEmpty())		
		{
		$insertAttr2=\DB::table('prod_attribute_value')->insert(array('Prod_ID' => $newProd, 'Attrb_ID' => '2', 'Attrb_Value_ID' =>$chkAttr2[0]));
		
		}
		
	
		else
		{
		$attr2ID=\DB::table('attrb_value_rel')->insertGetID(array('Attrb_ID' => '2' , 'Attrb_Value' => $Attr2));
		$insertAttr2=\DB::table('prod_attribute_value')->insert(array('Prod_ID' => $newProd, 'Attrb_ID' => '2', 'Attrb_Value_ID' =>$attr2ID));
		}
	}
	
	if(!empty($Attr3))
	{
		$chkAttr3=\DB::table('attrb_value_rel')->where('Attrb_Value', $Attr3)->pluck('Attrb_Value_ID');

		if(!$chkAttr3->isEmpty())		
		{
		$insertAttr3=\DB::table('prod_attribute_value')->insert(array('Prod_ID' => $newProd, 'Attrb_ID' => '3', 'Attrb_Value_ID' =>$chkAttr3[0]));
		
		}
		
	
		else
		{
		$attr3ID=\DB::table('attrb_value_rel')->insertGetID(array('Attrb_ID' => '3' , 'Attrb_Value' => $Attr3));
		$insertAttr3=\DB::table('prod_attribute_value')->insert(array('Prod_ID' => $newProd, 'Attrb_ID' => '3', 'Attrb_Value_ID' =>$attr3ID));
		}
	}
	 if(!empty($Attr4))
	{
		$chkAttr4=\DB::table('attrb_value_rel')->where('Attrb_Value', $Attr4)->pluck('Attrb_Value_ID');

		if(!$chkAttr4->isEmpty())		
		{
		$insertAttr4=\DB::table('prod_attribute_value')->insert(array('Prod_ID' => $newProd, 'Attrb_ID' => '4', 'Attrb_Value_ID' =>$chkAttr4[0]));
		
		}
		
	
		else
		{
		$attr4ID=\DB::table('attrb_value_rel')->insertGetID(array('Attrb_ID' => '4' , 'Attrb_Value' => $Attr4));
		$insertAttr4=\DB::table('prod_attribute_value')->insert(array('Prod_ID' => $newProd, 'Attrb_ID' => '4', 'Attrb_Value_ID' =>$attr4ID));
		}
	}
	 if(!empty($Attr5))
	{
		$chkAttr5=\DB::table('attrb_value_rel')->where('Attrb_Value', $Attr5)->pluck('Attrb_Value_ID');

		if(!$chkAttr5->isEmpty())		
		{
		$insertAttr5=\DB::table('prod_attribute_value')->insert(array('Prod_ID' => $newProd, 'Attrb_ID' => '5', 'Attrb_Value_ID' =>$chkAttr5[0]));
		
		}
		
	
		else
		{
		$attr5ID=\DB::table('attrb_value_rel')->insertGetID(array('Attrb_ID' => '5' , 'Attrb_Value' => $Attr5));
		$insertAttr5=\DB::table('prod_attribute_value')->insert(array('Prod_ID' => $newProd, 'Attrb_ID' => '5', 'Attrb_Value_ID' =>$attr5ID));
		}
	}
	 if(!empty($Attr6))
	{
		$chkAttr6=\DB::table('attrb_value_rel')->where('Attrb_Value', $Attr6)->pluck('Attrb_Value_ID');

		if(!$chkAttr6->isEmpty())		
		{
		$insertAttr6=\DB::table('prod_attribute_value')->insert(array('Prod_ID' => $newProd, 'Attrb_ID' => '6', 'Attrb_Value_ID' =>$chkAttr6[0]));
		
		}
		
	
		else
		{
		$attr6ID=\DB::table('attrb_value_rel')->insertGetID(array('Attrb_ID' => '6' , 'Attrb_Value' => $Attr6));
		$insertAttr6=\DB::table('prod_attribute_value')->insert(array('Prod_ID' => $newProd, 'Attrb_ID' => '6', 'Attrb_Value_ID' =>$attr6ID));
		}
	}
	 if(!empty($Attr7))
	{
		$chkAttr7=\DB::table('attrb_value_rel')->where('Attrb_Value', $Attr7)->pluck('Attrb_Value_ID');

		if(!$chkAttr7->isEmpty())		
		{
		$insertAttr7=\DB::table('prod_attribute_value')->insert(array('Prod_ID' => $newProd, 'Attrb_ID' => '7', 'Attrb_Value_ID' =>$chkAttr7[0]));
		
		}
		
	
		else
		{
		$attr7ID=\DB::table('attrb_value_rel')->insertGetID(array('Attrb_ID' => '7' , 'Attrb_Value' => $Attr7));
		$insertAttr7=\DB::table('prod_attribute_value')->insert(array('Prod_ID' => $newProd, 'Attrb_ID' => '7', 'Attrb_Value_ID' =>$attr7ID));
		}
	}
	if(!empty($Attr8))
	{
		$chkAttr8=\DB::table('attrb_value_rel')->where('Attrb_Value', $Attr8)->pluck('Attrb_Value_ID');

		if(!$chkAttr8->isEmpty())		
		{
		$insertAttr8=\DB::table('prod_attribute_value')->insert(array('Prod_ID' => $newProd, 'Attrb_ID' => '8', 'Attrb_Value_ID' =>$chkAttr8[0]));
		
		}
		
	
		else
		{
		$attr8ID=\DB::table('attrb_value_rel')->insertGetID(array('Attrb_ID' => '8' , 'Attrb_Value' => $Attr8));
		$insertAttr8=\DB::table('prod_attribute_value')->insert(array('Prod_ID' => $newProd, 'Attrb_ID' => '8', 'Attrb_Value_ID' =>$attr8ID));
		}
	}
	if(!empty($Attr9))
	{
		$chkAttr9=\DB::table('attrb_value_rel')->where('Attrb_Value', $Attr9)->pluck('Attrb_Value_ID');

		if(!$chkAttr9->isEmpty())		
		{
		$insertAttr9=\DB::table('prod_attribute_value')->insert(array('Prod_ID' => $newProd, 'Attrb_ID' => '9', 'Attrb_Value_ID' =>$chkAttr9[0]));
		
		}
		
	
		else
		{
		$attr9ID=\DB::table('attrb_value_rel')->insertGetID(array('Attrb_ID' => '9' , 'Attrb_Value' => $Attr9));
		$insertAttr9=\DB::table('prod_attribute_value')->insert(array('Prod_ID' => $newProd, 'Attrb_ID' => '9', 'Attrb_Value_ID' =>$attr9ID));
		}
	}
	
}
$resp=array('Product added');
return $resp;
}
}
	
		
	



	
	
	
	
	

