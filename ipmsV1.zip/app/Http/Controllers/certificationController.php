<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Input;
//use Illuminate\Http\Request;
use Request;
use File;
use Illuminate\Support\Facades\Crypt;
use Hash;

class certificationController extends Controller
{
	
    public function getAssociate()
	{
		$assoc_details=\DB::table('associate')
		->join ('status','associate.Assoc_Status','=','status.Assoc_Status')
			->join ('associate_details', 'associate.Assoc_ID', '=','associate_details.Assoc_ID')
			->join ('location','associate_details.Loc_ID','=','location.Loc_ID')
			//->join ('associate_segment_rate','associate_segment_rate.Assoc_ID','=','associate.Assoc_ID')
			//->join ('services','associate_details.service_ID','=','services.service_ID')
			//->join ('units','associate_details.Unit_ID','=','units.Unit_ID')
			
			->select('associate.Assoc_ID','associate.Assoc_code','associate.Assoc_FirstName','associate.Assoc_MiddleName','associate.Assoc_LastName','associate_details.Loc_ID','associate.Assoc_Status','associate.Assoc_Type','location.Loc_Name','status.Status_ColorCode','status.Status_Code','status.Status_Action','associate_details.No_Projects','associate_details.Total_Amount')//'associate_segment_rate.Pattern','associate_segment_rate.StdRateLabour','associate_segment_rate.StdRateMatLabour')
			->orderby('associate.Assoc_ID','DESC')
			//->select('associate.Assoc_code','associate.Assoc_FirstName','associate.Assoc_MiddleName','associate.Assoc_LastName','associate.Loc_ID','associate.Assoc_Status','associate.Assoc_Type','location.Loc_Name')'associate_details.bill_pattern','associate_details.Segment_ID','segment.segment_Name','associate_details.service_ID','services.service_Name','associate_details.stdRate','units.Unit_Code',
			//->where('associate.Assoc_ID','1534')
			->get()->map(function ($item) {
    return get_object_vars($item);});
	//echo $assoc_details;
	$response=array('response'=>'session start','success'=>true,$assoc_details);
		return $response;
		
	}
	public function getOneAssociate($id)
	{
		$assoc_details=\DB::table('associate')
		->join ('status','associate.Assoc_Status','=','status.Assoc_Status')
		->join ('contacts','associate.Contact_ID','=','contacts.Contact_ID')
			->join ('associate_details', 'associate.Assoc_ID', '=','associate_details.Assoc_ID')
			->join ('location','associate_details.Loc_ID','=','location.Loc_ID')
			->join ('address','associate.Address_ID','=','address.Address_ID')
			->join ('branch','associate.Branch_ID','=','branch.Branch_ID') 
			->join ('associate_segment_rate', 'associate.Assoc_ID','=','associate_segment_rate.Assoc_ID')
			->join ('segment','associate_segment_rate.segment_ID','=','segment.segment_ID')
			//->join ('services','associate_segment_rate.service_ID','=','services.service_ID')
			//->join ('units','associate_details.Unit_ID','=','units.Unit_ID')
			->where('associate.Assoc_ID',$id)
			
			->distinct('associate_segment_rate.segment_ID')
			->select('associate.Assoc_FirstName','associate.Assoc_MiddleName','associate.Assoc_LastName','associate_details.Loc_ID','location.Loc_Name','contacts.Contact_phone','contacts.Contact_ID','associate_details.No_Projects',  'associate_details.Total_Amount','address.Address_line1','address.Address_line2','address.Address_town','contacts.Contact_name','contacts.Contact_whatsapp','contacts.Contact_phone','Associate.Assoc_Type','associate_details.Keral_WKRS','associate_details.NonKerala_WKRS','associate_details.Total_WRKS','associate_details.Qualification','associate_details.Prof_Qualification','associate_details.Experiece','associate_details.No_Projects','associate_details.Total_Amount','branch.Branch_Name','associate_details.Rating')
			//->groupBy('associate_segment_rate.segment_ID')
			//->groupBy('associate_segment_rate.service_ID')
			//->select('associate.Assoc_code','associate.Assoc_FirstName','associate.Assoc_MiddleName','associate.Assoc_LastName','associate.Loc_ID','associate.Assoc_Status','associate.Assoc_Type','location.Loc_Name')
			//->where('associate.Assoc_ID','1534')
			->get()->map(function ($item) {
    return get_object_vars($item);});
	//echo $assoc_details;
	$response=array('response'=>'One Associate details','success'=>true,$assoc_details);
		return $response;
		
	}
	public function getProject($id)
	{
		$project_detail=\DB::table('associate_project')
		
		->join('customer', 'associate_project.Cust_ID','=','customer.Cust_ID')
		->join('Location', 'customer.Loc_ID','=','Location.Loc_ID')
		->where ('associate_project.Assoc_ID',$id)
		->select('customer.Cust_ID','customer.Cust_Name','customer.Contact_No','associate_project.Work_Detail','Location.Loc_Name')
	
		->get()->map(function ($item) {
    return get_object_vars($item);});
	//echo $project_details;
	$project_count=count($project_detail);
	$response=array('response'=>'project details retreived','success'=>true,$project_detail,'count'=>$project_count);
		return $response;
		
	}
	public function getOneProject($id)
	{
		$project_details=\DB::table('associate_project')
		
		->join('customer', 'associate_project.Cust_ID','=','customer.Cust_ID')
	->where ('associate_project.Assoc_ID',$id)
	->where('associate_project.QAStatus',0)
		
		->select('associate_project.Assoc_ID','associate_project.Cust_ID','customer.Cust_Name','customer.Contact_No','associate_project.Work_Detail','associate_project.QAStatus')
		
		->get()->map(function ($item) {
    return get_object_vars($item);});
	//echo $project_details;
	$project_count=count($project_details);
	$response=array('response'=>'project details retreived','success'=>true,$project_details,'count'=>$project_count);
		return $response;
		
	}
	public function getOneProjectFeed($id)
	{
		$project_details=\DB::table('associate_project')
		
		->join('customer', 'associate_project.Cust_ID','=','customer.Cust_ID')
	
		
		->select('associate_project.Assoc_ID','customer.Cust_ID','customer.Cust_Name','customer.Contact_No','associate_project.Work_Detail')
		->where ('associate_project.Assoc_ID',$id)
	->where('associate_project.FeedStatus','0')
		->get()->map(function ($item) {
    return get_object_vars($item);});
	//echo $project_details;
	$project_count=count($project_details);
	$response=array('response'=>'project details retreived','success'=>true,$project_details,'count'=>$project_count);
		return $response;
		
	}
	public function getOneCustomer($id)
	{
		$customer=\DB::table('customer')
		
		->join('associate_project', 'associate_project.Cust_ID','=','customer.Cust_ID')
		//->join('associate_rating','associate_rating.Cust_ID','=','associate_project.Cust_ID')
	
		
		->select('associate_project.Assoc_ID','associate_project.Work_Detail','customer.Cust_ID','customer.Cust_Name','customer.Contact_No','associate_project.Work_Detail','associate_project.OrderValue','associate_project.Rate_Unit')
		//->where ('customer.Assoc_ID',$id)
		->where('customer.Cust_ID',$id)
		
	
		->get()->map(function ($item) {
    return get_object_vars($item);});
	$customer_count=count($customer);
	$response=array('response'=>'customer details retreived','success'=>true,$customer,'count'=>$customer_count);
		return $response;
		
	}
	public function getOneCustomerqa($id)
	{
		$customer=\DB::table('customer')
		
		->join('associate_project', 'associate_project.Cust_ID','=','customer.Cust_ID')
		->join('associate_rating','associate_rating.Cust_ID','=','associate_project.Cust_ID')
	
		
		->select('associate_project.Assoc_ID','associate_project.Work_Detail','customer.Cust_ID','customer.Cust_Name','customer.Contact_No','associate_project.Work_Detail','associate_project.OrderValue','associate_project.Rate_Unit','associate_rating.Rating')
		//->where ('customer.Assoc_ID',$id)
		->where('customer.Cust_ID',$id)
		
	
		->get()->map(function ($item) {
    return get_object_vars($item);});
	$customer_count=count($customer);
	$response=array('response'=>'customer details retreived','success'=>true,$customer,'count'=>$customer_count);
		return $response;
		
	}
	public function getSegments()
	{
		$assoc_segments=\DB::table('segment')->get();
		$segments=array('response'=>'segments retrieved','success'=>true,$assoc_segments);
		return $segments;
	}
	public function getCategories($id)
	{
		 $id = explode(',', str_replace("[", "", str_replace("]", "", $id)));
		 $assoc_category=\DB::table('services')->select(\DB::raw('concat(Segment_ID, "_", Service_ID) as Service_ID'), 'Service_Name')->whereIn('Segment_ID',$id)->get();	
		 $categories=array('response'=>'segments retrieved','success'=>true,$assoc_category);
		 return $categories;
		
	}
	public function getCategory($id)
	{
		
		 $assoc_category=\DB::table('services')->select('Service_ID','Service_Name')->where('Segment_ID',$id)->get();	
		 $categories=array('response'=>'segments retrieved','success'=>true,$assoc_category);
		 return $categories;
		
	}
	public function getBranches()
	{
		$branch=\DB::table('branch')->select('Branch_ID','Branch_Name')->get();
		$branches=array('response'=>'branches retrieved','success'=>true,$branch);
		return $branches;
		
	}
	public function getOneCategory($id)
	{
		$category=\DB::table('services')->select('Service_ID','Service_Name','Service_Code')->where('Segment_ID',$id)->get();
		$cat=array('response'=>'category retrieved','success'=>true,$category);
		return $cat;
		
	}
	public function getUnits()
	{
		$units=\DB::table('units')->select('Unit_ID','Unit_Code')->get();
		$unit=array('response'=>'units retrieved','success'=>true,$units);
		return $unit;
		
	}
	public function getLocations()
	{
		$locations=\DB::table('location')->select('Loc_ID','Loc_Name')->orderby('Loc_Name')->get();
		$location=array('response'=>'locations retrieved','success'=>true,$locations);
		return $location;
		
	}
	public function addAssociate(Request $req)
	{
		
		/*$FirstName=$req->input('FirstName');
		$MidName=$req->input('MidName');
		$LastName=$req->input('LastName');
		$Type=$req->input('Type');
		$City=$req->input('City');*/
		/*$Keralite_Workers= $req->input('Keralite_Workers');
		$Non_Keralite_Workers= $req->input('Non_Keralite_Workers');
		$Total_Workers= $req->input('Total_Workers');
		$Qualifi= $req->input('Qualifi');
		$ProfQuali= $req->input('ProfQuali');
		$Years= $req->input('Years');
		$Proj_Nos= $req->input('Proj_Nos');
		$Total_Value= $req->input('Total_Value');
		$Territory= $req->input('Territory');
		$billing= $req->input('billing');
		$willing= $req->input('willing');
		$services= $req->input('services');
		$categories= $req->input('categories');
		$Quality= $req->input('Quality');
		$StdRate= $req->input('StdRate');
		$Plans= $req->input('Plans');
		$Unit= $req->input('Unit');
		$Address1 = $req ->input('Address1');
		$Address2 = $req ->input('Address2');
		$City=$req ->input('City');
		$Contact_Person=$req -> input('Contact_Person');
		$Contact_Number=$req -> input('Contact_Number');
		$Whatsapp_Number=$req -> input('Whatsapp_Number');*/
			
		
		
		
		/*$add=\DB::table('associate')->insertGetID(array(
            'Assoc_FirstName'     =>   $FirstName, 
            'Assoc_MiddleName'   =>   $MidName,            
			'Assoc_LastName'   =>   $LastName,         
		     
			'Assoc_Type'   =>   $Type,          
			'Loc_ID'   =>   $City));  
			$response =array('response'=>'assoc registration completed', $add);
		return $response;*/
		/*if(!empty($add))
   		{//add contain assocID
			$details=\DB::table('associate_details')->insert(array(
			'Assoc_ID' => $add,
			'Keral_WKRS' => $Keralite_Workers,
			'NonKerala_WKRS' =>$Non_Keralite_Workers,
			'Total_WRKS' => $Total_Workers,
			'Qualification' =>$Qualifi,
			'Prof_Qualification' => $ProfQuali,
			'Experiece' =>$Years,
			'No_Projects' =>$Proj_Nos,
			'Total_Amount' =>$Total_Value,
			'Loc_ID' =>$Territory,
			'Bill_Pattern' =>$billing,
			'Willing' =>$willing,
			'Segment_ID' =>$services,
			'Service_ID' =>$categories,
			'Quality' =>$Quality,
			'StdRate' =>$StdRate,
			'Future_Plans' =>$Plans,
			'Unit_ID' =>$Unit,
												
			
			
			));
			$address=\DB::table('address')->insertGetID(array(
			'Address_line1' => $Address1,
			'Address_line2' => $Address2,
			'Address_town' => $City,
			
			
			));
			if(!empty($address))//address contain addressID
			{$contact=\DB::table('contacts')->insertGetID(array(
			'Contact_name' => $Contact_Person,
			'Contact_phone' => $Contact_Number,
			'Contact_whatsapp' => $Whatsapp_Number));
			if(!empty($contact))//contains contactID
			{
				
				$update_assoc=\DB::table('associate')
				->where('Assoc_ID',$add)
				->update(array('Assoc_Code' => 'A00'.$add, 'Address_ID' => $address, 'Contact_ID' =>$contact));
			}
				
			}
			$response =array('response'=>'assoc registration completed', $update_assoc);
		return $response;*/
		
		$associate = Request::json()->all();
		
		
		$add=\DB::table('associate')->insertGetID(array(
		'Branch_ID' => $associate['Branch'],
            'Assoc_FirstName'     =>  $associate['FirstName'], 
            'Assoc_MiddleName'   =>   $associate['MidName'],            
			'Assoc_LastName'   =>   $associate['LastName'],          
		     
			'Assoc_Type'   =>   $associate['Type'],          
			
			 
			  
     ));
	 //$response =array('response'=>'associate added', $add);
		//return $response;
	//$response =array('response'=>'associtae tabledata added',$add);
		//return $response;
	if(!empty($add))
   		{//add contain assocID
		$details=\DB::table('associate_details')->insert (array('Assoc_ID' => $add,'Keral_WKRS' => $associate['Keralite_Workers'],'NonKerala_WKRS' =>$associate['Non_Keralite_Workers'],
			'Total_WRKS' => $associate['Total_Workers'],
			'Qualification' =>$associate['Qualifi'],
			'Prof_Qualification' => $associate['ProfQuali'],
			'Experiece' =>$associate['Years'],
			'No_Projects' =>$associate['Project_Nos'],
			'Total_Amount' =>$associate['Total_Value'],
			'Loc_ID' =>$associate['Territory'],
			//'Bill_Pattern' =>$associate['billing'],
			'Willing' =>$associate['willing'],
			//'Segment_ID' =>$associate['services'],
			//'Service_ID' =>$associate['categories'],
			'Quality' =>$associate['Quality'],
			//'StdRate' =>$associate['StdRate'],
			'Future_Plans' =>$associate['Plans'],
			//'Unit_ID' =>$associate['Unit']
			'Radius' => $associate['Radius']
			));
			if(!empty($details))
			{
				$cat=$associate['categories'];
				$segment=$associate['services'];
				$segID;
				$i=0;
				//$id = explode(',', str_replace("[", "", str_replace("]", "", $cat)));

				foreach ($cat as $c) {
					$id=explode('_',str_replace("\"", "", $c));
					$segID[$i]=(int)$id[0];
					$seg=\DB::table('associate_segment_rate')->insert(array(
					'Assoc_ID' => $add,
					'Segment_ID' => $id[0],
					'Service_ID' => $id[1]));
					$i++;
				}

				//$id = explode(',', str_replace("[", "", str_replace("]", "", $segment)));
				$diff=array_diff($segID, $segment);
				
				foreach ($diff as $c) {
					
					$seg=\DB::table('associate_segment_rate')->insert(array(
					'Assoc_ID' => $add,
					'Segment_ID' => $c,
					'Service_ID' => 0));
				}
			

			if(!empty($seg))
			{
			$address=\DB::table('address')->insertGetID(array(
			'Address_line1' => $associate['Address1'],
			'Address_line2' => $associate['Address2'],
			'Address_town' => $associate['City']
			
			
			));
			if(!empty($address))//address contain addressID
			{
				$contact=\DB::table('contacts')->insertGetID(array(
			'Contact_name' => $associate['Contact_Person'],
			'Contact_phone' => $associate['Contact_Number'],
			'Contact_whatsapp' => $associate['Whatsapp_Number']));
			if(!empty($contact))//contains contactID
			{
				$update_assoc=\DB::table('associate')
				->where('Assoc_ID',$add)
				->update(array('Assoc_Code' => 'A00'.$add, 'Address_ID' => $address, 'Contact_ID' =>$contact,'Assoc_Status'=>'5'));
				$response =array('response'=>'associate added','success'=>true,$add);
		return $response;
				
		
			}
				
			}
			}
			}
			
		
			}
			else
			{
				$response =array('response'=>'associate added','success'=>false);
		return $response;
		
			}
			
		
		
		
		
		
		
	}

		
		
public function addProject(Request $r)
{
	
	$input = Request::json()->all();
	$cust_ID = \DB::table('customer')->insertGetID(array(
	'Assoc_ID' => $input['id'],
	'Cust_Name' => $input['custName'],
	'Contact_No'   =>  $input['Contact'], 
	'Loc_ID' => $input['Location'],
	));
	if(!empty($cust_ID))
	{
		$work=\DB::table('associate_project')->insert(array(
	'Assoc_ID' => $input['id'],
	'Cust_ID' => $cust_ID,
	'Work_Detail' =>$input['WorkDetails']
	));
	
	$response =array('response'=>'success', $cust_ID,$work,$input['id']);
		return $response;
	}
				
	
			
}

public function addFeedback(Request $req)
{
	
	/*$a=$req->input('assoc_ID');
	$b=$req->input('custName');
	$c=$req->input('contact');
	$d=$req->input('orderValue');
	$e=$req->input('Quality');
	$f=$req->input('workDetails');
	$g=$req->input('Behaviour');
	$h=$req->input('Knowledge');
	$i=$req->input('WorkLevel');
	$j=$req->input('Time');
	$k=$req->input('Payment');
	$l=$req->input('Pricing');
	$m=$req->input('Service');
	$n=$req->input('rate');
	$o=$req->input('unit');
	$rateUnit=$n.$o;
	$rating=($g+$h+$e+$i+$j+$k+$l+$m)/8;
	
	$params=\DB::table('associate_rating')->insert(array(
				
				'Cust_ID' => $b,
			'Param1' => $g,
			'Param2' => $h,
			'Param3' => $e,
			'Param4' => $i,
			'Param5' => $j,
			'Param6' => $k,
			'Param7' => $l,
			'Param8' => $m,
			'Rating' => $rating	
			
			));
			//$rating_count=count($params);
			if(!empty($params))
			{
				$other=\DB::table('associate_project')
	->where('associate_project.Assoc_ID',$a)
	->where('associate_project.Cust_ID',$b)
	->update(array(								
			'OrderValue' => $d,			
			'Rate_Unit' => $rateUnit,
			));		
			
		
			if(!empty($other))
			{
				
			
			$tableData=\DB::table('associate_project')	
	->join('customer', 'customer.Cust_ID','=','associate_project.Cust_ID')
	->join('associate_rating', 'associate_project.Cust_ID','=','associate_rating.Cust_ID')
	->where('associate_project.Assoc_ID',$a)
	//->where('associate_project.Cust_ID',$b)
	->get()->map(function ($item) {
    return get_object_vars($item);});
	$data_count=count($tableData);
	
	
			}
			
		
			}
			$response =array('success'=>true, 'Tabledata'=>$tableData,'datacount'=>$data_count);
		return $response;*/
	
	
	
	
$feedback = Request::json()->all();
$id=$feedback['assoc_ID'];

	$rateUnit=$feedback['rate'].''.$feedback['unit'];
	$rating=($feedback['Behaviour']+$feedback['Knowledge']+$feedback['Quality']+$feedback['WorkLevel']+$feedback['Time']+$feedback['Payment']+$feedback['Pricing']+$feedback['Service'])/8;
	
	
	$params=\DB::table('associate_rating')->insert(array(
				
				'Cust_ID' => $feedback['custName'],
			'Param1' => $feedback['Behaviour'],
			'Param2' => $feedback['Knowledge'],
			'Param3' => $feedback['Quality'],
			'Param4' => $feedback['WorkLevel'],
			'Param5' => $feedback['Time'],
			'Param6' => $feedback['Payment'],
			'Param7' => $feedback['Pricing'],
			'Param8' => $feedback['Service'],
			'Rating' => $rating	
			
			));
			//$rating_count=count($params);
			if(!empty($params))
			{
				$other=\DB::table('associate_project')
	->where('associate_project.Assoc_ID',$feedback['assoc_ID'])
	->where('associate_project.Cust_ID',$feedback['custName'])
	->update(array(								
			'OrderValue' => $feedback['orderValue'],			
			'Rate_Unit' => $rateUnit,
			'FeedStatus' => '1'
			));		
			
		
			/*if(!empty($other))
			{
				
			
			$tableData=\DB::table('associate_project')	
	->join('customer', 'customer.Cust_ID','=','associate_project.Cust_ID')
	->join('associate_rating', 'associate_project.Cust_ID','=','associate_rating.Cust_ID')
	->where('associate_project.Assoc_ID',$feedback['assoc_ID'])
	->where('associate_project.Cust_ID',$feedback['custName'])
	->get()->map(function ($item) {
    return get_object_vars($item);});
	$data_count=count($tableData);
	
	
			}*/
			$response =array('success'=>true,'id'=>$id);
		return $response;
		
			}
			

}
public function getFeedback($aid)
{
	$tableData=\DB::table('associate_project')	
	->join('customer', 'customer.Cust_ID','=','associate_project.Cust_ID')
	->join('associate_rating', 'associate_project.Cust_ID','=','associate_rating.Cust_ID')
	->where('associate_project.Assoc_ID',$aid)
	->where('associate_project.FeedStatus','1')
	//->where('associate_project.Cust_ID',$feedback['custName'])
	->get()->map(function ($item) {
    return get_object_vars($item);});
	$data_count=count($tableData);
	
	$response =array('success'=>true, $tableData);
		return $response;
}
public function addQARating(Request $request)
{
	$qaRating = Request::json()->all();
	$rating=floatval(($qaRating['QAP1']+$qaRating['QAP2']+$qaRating['QAP3']+$qaRating['QAP4'])/4);
	
	$QAP=\DB::table('associate_qarating')
	//->where('associate_qarating.Cust_ID',$qaRating['CustName'])
	->join('associate_Project','associate_project.Cust_ID','=','associate_qarating.Cust_ID')
	->where('associate_Project.Assoc_ID',$qaRating['assoc_ID'])
	->distinct('associate_qarating.Cust_ID')
	->get()->map(function ($item) {
    return get_object_vars($item);});
	$QAP_Count=count($QAP);
	if($QAP_Count<5)
	{
	
	$params=\DB::table('associate_qarating')->insert(array(
				
				'Cust_ID' => $qaRating['CustName'],
			'QAParam1' => $qaRating['QAP1'],
			'QAParam2' => $qaRating['QAP2'],
			'QAParam3' => $qaRating['QAP3'],
			'QAParam4' => $qaRating['QAP4'],
			'Rating' => $rating	
			
			));
			if(!empty($params))
			{
				$addrating=\DB::table('associate_details')->where('Assoc_ID',$qaRating['assoc_ID'])
				->update(array('Rating' =>$rating));
				$update=\DB::table('associate_project')
				->where('Cust_ID',$qaRating['CustName'])
				->update(array('QAStatus'=>'1') );
			
			}
			$response =array('response'=>'Data inserted','success'=>true, $QAP, $QAP_Count, $rating);
		return $response;
	}
	else if($QAP_Count=5)
	{		
	$response =array('response'=>'Last feedback', 'success'=>false,$QAP_Count);
		return $response;
	}
}
/*public function addAvgRating(Request $re)
{
	$value= Request::json()->all();
	$custID=$value['CustName'];
	$assocID=$value['assoc_ID'];
	$FeedRating=\DB::table('associate_rating')->select('Rating')
	->where('Cust_ID',$custID)->get();
	$QARting=\DB::table('associate_qarating')->select('Rating')
	->where('Cust_ID',$custID)->get();
	$rate=($FeedRating+$QARting)/2;
	$FullRating=\DB::table('associate_details')->update(array('Rating' => $rate));
		$resp=array('response'=>'Feedback rating retrieved','success'=>true,$QARting,$FeedRating,$FullRating);
		return $resp;
}*/
public function changeQAStatus(Request $r)
{
	
	$value= Request::json()->all();
	$id=$value['ID'];
	
	$action=$value['Action'];
	$sum=\DB::table('associate_qarating')->join('associate_project','associate_qarating.Cust_ID','=','associate_project.Cust_ID')->where('associate_project.Assoc_ID', $id)->sum('associate_qarating.Rating');
	$rating=$sum/5;
	$insertRate=\DB::table('associate_details')->where('associate_details.Assoc_ID',$id)->update(array('associate_details.Rating'=>$rating));
	
	if($action=="Verified")
	{
	$status=\DB::table('associate')
	->where('Assoc_ID',$id)
	->update(array('Assoc_Status' => '3'));
	$response =array('response'=>'QAStatus changed to certify', 'success'=>true,$status,$insertRate);
		return $response;
	}
	else if($action=="Rejected")
	{
		$status=\DB::table('associate')
	->where('Assoc_ID',$id)
	->update(array('Assoc_Status' => '7'));
	$response =array('response'=>'QAStatus changed to certify', 'success'=>true,$status,$insertRate);
		return $response;
	}
	else if($action=="VerifiedWC")
	{
		$cmnt=$value['comment'];
		$status=\DB::table('associate')
	->where('Assoc_ID',$id)
	->update(array('Assoc_Status' => '6'));
	$comment=\DB::table('associate_details')
	->where('Assoc_ID',$id)
	->update(array('Comment'=> $cmnt));
	
	$response =array('response'=>'QAStatus changed to certify', 'success'=>true,$status,$insertRate);
		return $response;
	}
		
	
	
	
}
public function changeRegStatus($id)
{
	
	$status=\DB::table('associate')
	->where('Assoc_ID',$id)
	->update(array('Assoc_Status' => '1'));
	$response =array('response'=>'Added changed to Registraion', 'success'=>true,$status);
		return $response;
}
public function changeVerifyStatus($id)
{
	
	$status=\DB::table('associate')
	->where('Assoc_ID',$id)
	->update(array('Assoc_Status' => '3'));
	$response =array('response'=>'certified', 'success'=>true,$status);
		return $response;
}
public function changeFeedStatus($id)
{
	$status=\DB::table('associate')
	->where('Assoc_ID',$id)
	->update(array('Assoc_Status' => '2'));
	$response =array('response'=>'Registerd changed to QAVerified', 'success'=>true,$status);
		return $response;
}
public function checkQACount($id)
{
	$QAP=\DB::table('associate_qarating')
	//->where('associate_qarating.Cust_ID',$qaRating['CustName'])
	->join('associate_Project','associate_project.Cust_ID','=','associate_qarating.Cust_ID')
	->where('associate_Project.Assoc_ID',$id)
	->distinct('associate_qarating.Cust_ID')
	->get();
	$QAP_Count=count($QAP);
	
	if($QAP_Count<5)
	{
		$response=array('response'=>'5 data inserted','success'=>false, $QAP_Count);
		return $response;
	}
	else if($QAP_Count=5)
	{
		$response=array('response'=>'5 data inserted','success'=>true, $QAP_Count);
		return $response;
	}
}
public function file_uploadAadhar(Request $req)
{
	 
	
//$value= Request::file();
	$filename = Request::file('fileKey')->getClientOriginalName();
	//$file2=$value->file['fileKey'];
	//$attachment = Request::file(a);
	//$response=array('response'=>'file not uploaded','success'=>true, Request::all(),$filename);
		//return $response;
	if(Request::file('fileKey')){
		$file=Request::file('fileKey');
		$file->move('resources/assets/uploads/Aadhar',$filename);
	//echo '<img src = 'uploads/'.$file->getClientOriginalName()>';
	$response=array('response'=>'Aadhar uploaded','success'=>true);
		return $response;
	}
	else
	{
		$response=array('response'=>'file not uploaded','success'=>true);
		return $response;
	}
}
public function file_uploadAgreement(Request $req)
{
	 
	
//$value= Request::file();
	$filename1 = Request::file('fileKey1')->getClientOriginalName();
	//$file2=$value->file['fileKey'];
	//$attachment = Request::file(a);
	//$response=array('response'=>'file not uploaded','success'=>true, Request::all(),$filename);
		//return $response;
	if(Request::file('fileKey1')){
		$file=Request::file('fileKey1');
		$file->move('resources/assets/uploads/Agreement',$filename1);
		
	//echo '<img src = 'uploads/'.$file->getClientOriginalName()>';
	$response=array('response'=>'agreement uploaded','success'=>true);
		return $response;
	}
	else
	{
		$response=array('response'=>'file not uploaded','success'=>true);
		return $response;
	}
}
public function certification(Request $r)
{
	$values=Request::json()->all();
	$id=$values['assoc_ID'];
	$aadhar=$values['AadharNo'];
	$agree=$values['AgreeNo'];
	$documents=\DB::table('associate_documents')
	->insert(array('Assoc_ID' =>$id,'AadharFile' => $values['Aadhar'],'AgreementFile'=> $values['Agree'], 'AadharNo'=>$aadhar, 'AgreeNo'=>$agree));
	
	$response =array('response'=>'certified','success'=>true,$documents);
		return $response;
}
public function changeCertifyStatus($id)
{
	
		$updates=\DB::table('associate')
	->where('Assoc_ID',$id)
	->update(array('Assoc_Status' => '4'));
	$response =array('response'=>'cwertified', 'success'=>true,$updates);
		return $response;
	
}
	
	

public function getSegRate($id)
{
	$segments=\DB::table('associate_segment_rate')
	->join ('segment','associate_segment_rate.Segment_ID','=','segment.Segment_ID')
	->join('services','associate_segment_rate.Service_ID','=','services.Service_ID')
	->select('associate_segment_rate.Assoc_ID','associate_segment_rate.Segment_ID','associate_segment_rate.Service_ID','Segment.Segment_Name','Services.Service_Name')
	  ->where('associate_segment_rate.Assoc_ID',$id)
	  ->where('associate_segment_rate.Status','1')->get();
	$res=array('response'=>'segment recieved', 'success'=>true,$segments);
		return $res;
}
public function getSegmentDetails($id)
{
	$rates=\DB::table('associate_segment_rate')
	->join ('segment','associate_segment_rate.Segment_ID','=','segment.Segment_ID')
	->join('services','associate_segment_rate.Service_ID','=','services.Service_ID')
	->select('associate_segment_rate.Assoc_ID','associate_segment_rate.Segment_ID','associate_segment_rate.Service_ID','Segment.Segment_Name','Services.Service_Name','associate_segment_rate.Pattern','associate_segment_rate.StdRateLabour',	'associate_segment_rate.StdRateMatLabour')
	  ->where('associate_segment_rate.Assoc_ID',$id)
	  ->where('associate_segment_rate.Status','2')->get();
	$res=array('response'=>'segment recieved', 'success'=>true,$rates);
		return $res;
}
//To get associate details based on Seg, Serv search
public function searchAssociate($value)
{

	$assocDetails=\DB::table('associate_segment_rate')
	->join('associate','associate.Assoc_ID','=','associate_segment_rate.Assoc_ID')
	->join ('status','associate.Assoc_Status','=','status.Assoc_Status')
			->join ('associate_details', 'associate.Assoc_ID', '=','associate_details.Assoc_ID')
			->join ('location','associate_details.Loc_ID','=','location.Loc_ID')
	->where('associate_segment_rate.Service_ID',$value)
	->select('associate_segment_rate.Assoc_ID','associate.Assoc_code','associate.Assoc_FirstName', 'associate.Assoc_MiddleName','associate.Assoc_LastName','associate_details.Loc_ID', 'location.Loc_Name','status.Status_ColorCode','status.Status_Code','status.Status_Action')
	->get();
	$res=array('response'=>'segment recieved', 'success'=>true,$assocDetails);
	return $res;
}
public function saveRate(Request $r1)
{
	
	$data=Request::json()->all();
	//$seg=$data['param1'];
	$data1 = json_decode($data['param1'], true);
	$segID=$data1['Segment_ID'];
	$serID=$data1['Service_ID'];
	$data2 = json_decode($data['param2'], true);
	
	$id=$data1['Assoc_ID'];
	$save=\DB::table('associate_segment_rate')
	->where('Assoc_ID',$id)
	->where('Segment_ID',$segID)
	->where ('Service_ID',$serID)
	->update(array(
	'Pattern'=>$data2['pattern'],
	'StdRateLabour'=>$data2['rateL'],
	'StdRateMatLabour'=>$data2['rateML'],
	'Status' => '2'));
	$res=array('response'=>'rate updated', 'success'=>true,$data2, $segID,$serID);
		return $res;
}
public function getServiceList($id)
{
	$services=\DB::table('services')->where('Segment_ID',$id)
	->get();
	$resp=array($services);
	return $resp;
}
public function getUserName($id)
{
	$name=\DB::table('associate')->select('Assoc_FirstName')->where('Assoc_ID',$id)->get();

	/*if(!empty($name))
	{
		$hash=Hash::make($json["Assoc_FirstName"].'123');
		$login=\DB::table('logins')->insert(array(
		'User_Name' => $json["Assoc_FirstName"],
		'User_Login' => $json["Assoc_FirstName"],
		'User_Password' => $hash,
		'Role_ID' =>'4'));
		
		
	}*/
	$resp=array('success'=>true,$name);
	return $resp;
}
public function createLogin(Request $r)
{
	$details=Request::json()->all();
	$userName=$details['Assoc_FirstName']['0'];
	$hash=Hash::make($details['Assoc_FirstName']['0'].'123');
		$login=\DB::table('logins')->insert(array(
		'User_Name' => $details['Assoc_FirstName']['0'],
		'User_Login' => $details['Assoc_FirstName']['0'],
		'User_Password' => $hash,
		'Role_ID' =>'4'));
		$resp=array('Login Created','success'=>true,$hash,$login);
	return $resp;
}
public function getHash($value)
{
	$hash=Hash::make($value);
	$response=array($hash);
	return $response;
}
public function getSegmentAssoc($id)
{
	//$cp = array();
	$seg=\DB::table('associate_segment_rate')
	->join('segment','associate_segment_rate.Segment_ID','=','segment.Segment_ID')
	->where('Assoc_ID',$id)
	->select('segment.Segment_Name')->distinct('segment.Segment_Name')->get();
	
	//$arr=array($seg);
	
	//$collapsed = $seg['Segment_Name']->collapse();
	//dd($collapsed);
	//dd($seg);
	$response=$seg;
	return $response;
	
}
public function getRating($id)
{
	
}
public function getUserPermission($name)
{
	$perm=\DB::table('logins')->join('userrole_privillage','userrole_privillage.Role_ID','=','logins.Role_ID')
	->join('menu_previllage','menu_previllage.Priv_ID','=','userrole_privillage.Priv_ID')
	->where('logins.User_Name',$name)
	->select('userrole_privillage.Role_ID','userrole_privillage.Priv_ID','menu_previllage.Priv_ID','menu_previllage.Priv_Name','menu_previllage.IsActive')->get();
	 $res=array('Hai',$perm);
	 return $res;

	
}
	
	
}
	


	
	
				





		